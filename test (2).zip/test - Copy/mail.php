<?php
//get data from form  
$name = $_POST['name'];
$email= $_POST['email'];
$sub= $_POST['subject'];
$message= $_POST['message'];
$to = "m.selvan@waferlead.com";
$subject = "Mail From your Website";
$txt = $message;
$headers = "From: " . $email . "\r\n";
if($email!=NULL){
    mail($to,$subject,$txt,$headers);
	//echo $name;
}
//redirect
header("Location:index.html#contact");
?>